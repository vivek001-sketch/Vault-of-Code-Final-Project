# Personal To-Do List Application (CLI)

A simple, local, menu-driven to-do list app written in Python.

## Features
- Add, view, edit, complete, and delete tasks
- Categorize tasks (Work, Personal, Urgent, Other or custom)
- Persistent storage in `tasks.json` (no database needed)
- Clean command-line UI

## Requirements
- Python 3.8+ (no third-party packages required)

## How to Run
```bash
cd todo_app
python todo.py
```
Your tasks will be saved to `tasks.json` in the same directory.

## Project Structure
```
todo_app/
  ├── todo.py         # Main application logic
  ├── tasks.json      # Persistent data storage
  └── README.md       # Documentation
```

## Notes
- You can filter tasks by category or status when viewing.
- Edit lets you update title, description, and category.
- The app autosaves after each change.
